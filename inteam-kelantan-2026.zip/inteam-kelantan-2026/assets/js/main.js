// assets/js/main.js
// Skrip tambahan jika diperlukan pada masa hadapan.
