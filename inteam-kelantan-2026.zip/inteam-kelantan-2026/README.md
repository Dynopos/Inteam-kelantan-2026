# 🎵 Konsert Mengimbau Kenangan InTeam Kelantan 2026

> Laman web rasmi tentative & poster promosi untuk Konsert Mengimbau Kenangan InTeam Kelantan 2026.

---

## 📋 Maklumat Konsert

| | |
|---|---|
| **Tarikh** | 24 Julai 2026 (Jumaat) |
| **Masa** | 6:00 PM – 12:00 AM |
| **Tempat** | Dewan DATC UMK Bachok, Kelantan |
| **Artis** | InTeam feat. Dr. Fitri Haris (UNIC) |

---

## 🗂️ Struktur Fail

```
inteam-kelantan-2026/
├── index.html          ← Laman utama (poster + tentative)
├── poster.html         ← Poster promosi sahaja
├── tentative.html      ← Tentative program sahaja
├── README.md           ← Fail ini
└── assets/
    ├── css/
    │   └── style.css   ← Stail tambahan (jika ada)
    └── js/
        └── main.js     ← Skrip tambahan (jika ada)
```

---

## 🚀 GitHub Pages

Laman ini boleh diakses terus melalui GitHub Pages:

```
https://<username>.github.io/inteam-kelantan-2026/
```

### Cara Aktifkan GitHub Pages:
1. Pergi ke **Settings** → **Pages**
2. Di bawah **Source**, pilih `main` branch → folder `/ (root)`
3. Klik **Save**
4. Tunggu beberapa minit — laman akan aktif

---

## 📄 Halaman

| Fail | Keterangan |
|---|---|
| `index.html` | Laman utama dengan poster & tentative |
| `poster.html` | Poster konsert (format A3) |
| `tentative.html` | Tentative program lengkap |

---

*© 2026 Konsert InTeam Kelantan. Semua hak terpelihara.*
